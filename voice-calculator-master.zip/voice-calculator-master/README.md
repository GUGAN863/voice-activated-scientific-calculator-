# Voice calculator
Voice calculator with support for simple commands
