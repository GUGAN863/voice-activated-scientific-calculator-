from calculator import calculate, listen

user = listen()
calculate(user)
